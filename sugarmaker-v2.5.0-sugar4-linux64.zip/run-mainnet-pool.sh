./sugarmaker -a YespowerSugar -o stratum+tcp://1pool.sugarchain.org:3333 -u sugar1qghm8ngwc56f5lwudg8jc3ujepupt2nz5v03r2f -t1
