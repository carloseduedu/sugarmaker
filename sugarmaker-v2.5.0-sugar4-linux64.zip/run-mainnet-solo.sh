./sugarmaker -a YespowerSugar -o http://127.0.0.1:34229 -u RPCUSER -p RPCPASSWORD --coinbase-addr=sugar1qghm8ngwc56f5lwudg8jc3ujepupt2nz5v03r2f -t1
